const defaultMessages = [
  { sender: "boy", text: "Where are you? 😅" },
  { sender: "girl", text: "Running! 🏃‍♀️💨" },
  { sender: "boy", text: "You said that 10 minutes ago 😂" },
  { sender: "girl", text: "I had to dodge a bus." },
  { sender: "boy", text: "On foot? 🤨" },
  { sender: "girl", text: "And a giant chicken." },
  { sender: "boy", text: "A giant WHAT?" },
  { sender: "girl", text: "Long story. Keep waiting ❤️" }
];

let messages = [...defaultMessages];
let timers = [];
let mediaRecorder;
let recordedChunks = [];

const messagesEl = document.getElementById("messages");
const chatEl = document.getElementById("chat");
const stageEl = document.getElementById("stage");
const bgMode = document.getElementById("bgMode");
const delayInput = document.getElementById("delayInput");
const scaleInput = document.getElementById("scaleInput");

function renderEditor() {
  messagesEl.innerHTML = "";
  messages.forEach((msg, index) => {
    const row = document.createElement("div");
    row.className = "message-row";

    const select = document.createElement("select");
    select.innerHTML = `<option value="boy">Boy</option><option value="girl">Girl</option>`;
    select.value = msg.sender;
    select.onchange = () => {
      messages[index].sender = select.value;
    };

    const text = document.createElement("textarea");
    text.value = msg.text;
    text.oninput = () => {
      messages[index].text = text.value;
    };

    const del = document.createElement("button");
    del.className = "delete";
    del.textContent = "×";
    del.onclick = () => {
      messages.splice(index, 1);
      renderEditor();
    };

    row.append(select, text, del);
    messagesEl.appendChild(row);
  });
}

function resetPreview() {
  timers.forEach(clearTimeout);
  timers = [];
  chatEl.innerHTML = "";
}

function playPreview() {
  resetPreview();
  const delay = Number(delayInput.value) || 850;

  messages.forEach((msg, index) => {
    const timer = setTimeout(() => {
      const bubble = document.createElement("div");
      bubble.className = `bubble ${msg.sender}`;
      bubble.textContent = msg.text;
      bubble.style.fontSize = `${30 * Number(scaleInput.value) / 100}px`;
      chatEl.appendChild(bubble);
    }, index * delay);
    timers.push(timer);
  });
}

function setBackground() {
  stageEl.className = "stage";
  stageEl.classList.add(`bg-${bgMode.value}`);
}

async function exportVideo() {
  resetPreview();

  if (!stageEl.captureStream) {
    alert("Your browser does not support screen capture from elements. Try Chrome.");
    return;
  }

  const stream = stageEl.captureStream(30);
  recordedChunks = [];

  mediaRecorder = new MediaRecorder(stream, { mimeType: "video/webm; codecs=vp9" });
  mediaRecorder.ondataavailable = event => {
    if (event.data.size > 0) recordedChunks.push(event.data);
  };

  mediaRecorder.onstop = () => {
    const blob = new Blob(recordedChunks, { type: "video/webm" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "dating-chat-overlay.webm";
    a.click();
    URL.revokeObjectURL(url);
  };

  mediaRecorder.start();
  playPreview();

  const totalDuration = messages.length * (Number(delayInput.value) || 850) + 1200;
  setTimeout(() => {
    mediaRecorder.stop();
  }, totalDuration);
}

document.getElementById("addBoy").onclick = () => {
  messages.push({ sender: "boy", text: "New boy message" });
  renderEditor();
};

document.getElementById("addGirl").onclick = () => {
  messages.push({ sender: "girl", text: "New girl message" });
  renderEditor();
};

document.getElementById("playBtn").onclick = playPreview;
document.getElementById("stopBtn").onclick = resetPreview;
document.getElementById("exportBtn").onclick = exportVideo;
bgMode.onchange = setBackground;

renderEditor();
setBackground();
playPreview();
