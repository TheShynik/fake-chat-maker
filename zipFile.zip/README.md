# Dating Chat Overlay Maker

Open `index.html` in Chrome.

What it does:
- edit boy/girl messages
- preview animated chat bubbles
- export WebM video
- use green screen background for easy overlay/keying in CapCut, Premiere, After Effects, etc.

Best place to host/build:
1. Replit — easiest.
2. Netlify Drop — easiest for publishing.
3. Vercel — good, but more developer-style.

For Replit:
- Create a new HTML/CSS/JS project.
- Upload these three files: index.html, style.css, script.js.
- Press Run.
